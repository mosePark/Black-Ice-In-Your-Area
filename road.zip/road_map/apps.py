from django.apps import AppConfig


class RoadMapConfig(AppConfig):
    name = 'road_map'
