from django.db import models

class Maps_road(models.Model):
    date = models.CharField(max_length=128)
    code = models.CharField(primary_key=True,max_length=128)
    Xvalue = models.FloatField()
    Yvalue = models.FloatField()
    predict = models.CharField(max_length=128)
    score1 = models.CharField(max_length=128)
    score2 = models.CharField(max_length=128)
    risk_index = models.CharField(max_length=128)
    score3 = models.CharField(max_length=128)
    score_word = models.CharField(max_length=128)
    score_icon = models.CharField(max_length=128)
    #score1 : 테두리 색상, score2 : 원 내부 색상, score3 : 마커색상, score_word=위험등급
    class Meta:
        ordering = ['code']