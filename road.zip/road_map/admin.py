from django.contrib import admin
from .models import Maps_road

admin.site.register(Maps_road)

# Register your models here.
