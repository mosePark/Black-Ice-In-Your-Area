from django.shortcuts import render
from django.http import HttpResponse
import datetime
from .models import Maps_road
from django.core import serializers
from django.forms.models import model_to_dict

#id:jhna2/pass:1234
def index(request):
    import pandas as pd
    # from sklearn.tree import DecisionTreeClassifier
    # from sklearn.externals import joblib
    import numpy as np
    from tqdm import tqdm

    # road = pd.read_csv("road_map/final_S.csv", encoding='euc-kr')
    # #road = pd.read_csv("road_map/final_E.csv", encoding='euc-kr')
    # file_name = 'road_map/mlp_512_256_30.pkl'
    # model = joblib.load(file_name)
    #
    # x_test = road[['s_elevation','e_elevation','pave','surface','classification','grooving','traffic',
    #     '합계일조시간(hr)','일강수량(mm)','강수계속시간(hr)','평균풍속(m/s)','평균이슬점온도(°C)',
    #     ]]
    # score = ['위험도']
    # y = np.zeros(shape=(len(x_test), 1))
    # for i in range(len(x_test)):
    #     y_predict = model.predict(x_test.loc[[i]])
    #     y[i] = y_predict
    #
    # df = pd.DataFrame(y)
    # df.columns = ['predict']
    # road_data = road[['date','czId', 's_Xvalue', 's_Yvalue','score1','score2']]
    # road_predict = pd.concat([road_data, pd.DataFrame(df)], axis=1, sort=False)
    road_predict = pd.read_csv("road_map/reg_road.csv", encoding='euc-kr')
    road = 0
    metrisData = Maps_road.objects.all()  # 테이블 데이타를 전부 가져오기 위한 메소드
    context = {'metrisData': metrisData}
    try:
        for i in tqdm(range(len(road_predict))):
            if road_predict['VMS_keyword'].iloc[i] == 0 or road_predict['VMS_keyword'].iloc[i] == 1 or road_predict['VMS_keyword'].iloc[i] == 2 or road_predict['VMS_keyword'].iloc[i] == 3:
                score_col1 = 'green'
                score_col2 = '#5CE546'
            elif road_predict['VMS_keyword'].iloc[i] == 4 or road_predict['VMS_keyword'].iloc[i] == 5 or road_predict['VMS_keyword'].iloc[i] == 6 or road_predict['VMS_keyword'].iloc[i] == 7:
                score_col1 = 'yellow'
                score_col2 = '#FFE062'
            else:
                score_col1 = 'red'
                score_col2 = '#CF1414'

            if road_predict['VMS_keyword'].iloc[i] == 0:
                road_predict['VMS_keyword'].iloc[i] = "건조"
            elif road_predict['VMS_keyword'].iloc[i] == 1:
                road_predict['VMS_keyword'].iloc[i] = "비예보"
            elif road_predict['VMS_keyword'].iloc[i] == 2:
                road_predict['VMS_keyword'].iloc[i] = "눈예보"
            elif road_predict['VMS_keyword'].iloc[i] == 3:
                road_predict['VMS_keyword'].iloc[i] = "눈/비예보"
            elif road_predict['VMS_keyword'].iloc[i] == 4:
                road_predict['VMS_keyword'].iloc[i] = "비"
            elif road_predict['VMS_keyword'].iloc[i] == 5:
                road_predict['VMS_keyword'].iloc[i] = "눈"
            elif road_predict['VMS_keyword'].iloc[i] == 6:
                road_predict['VMS_keyword'].iloc[i] = "어는비"
            elif road_predict['VMS_keyword'].iloc[i] == 7:
                road_predict['VMS_keyword'].iloc[i] = "노면습기"
            elif road_predict['VMS_keyword'].iloc[i] == 8:
                road_predict['VMS_keyword'].iloc[i] = "노면미끄럼"
            else:
                road_predict['VMS_keyword'].iloc[i] = "결빙"

            if road_predict['risk_index'].iloc[i] <= 0.33 :
                score_col3 = 'b'
                score_icon = 's'
                score_word = 'Safety'
                road_predict['risk_index'].iloc[i] = round(road_predict['risk_index'].iloc[i],2)
            elif road_predict['risk_index'].iloc[i] <= 0.66 :
                score_col3 = 'r'
                score_icon = 'c'
                score_word = 'Caution'
                road_predict['risk_index'].iloc[i] = round(road_predict['risk_index'].iloc[i],2)
            else:
                score_col3 = 'g'
                score_icon = 'w'
                score_word = 'Warning'
                road_predict['risk_index'].iloc[i] = round(road_predict['risk_index'].iloc[i],2)

            metrisdatas = Maps_road(date=road_predict['date'].iloc[i], code=road_predict['czId'].iloc[i],
                                    Xvalue=road_predict['s_Xvalue'].iloc[i],Yvalue=road_predict['s_Yvalue'].iloc[i],
                                    predict=road_predict['VMS_keyword'].iloc[i], score1=score_col1,score2=score_col2,
                                    risk_index=road_predict['risk_index'].iloc[i],score3=score_col3,score_word=score_word, score_icon=score_icon)
            metrisdatas.save()
    except Exception as e:
        metrisdatas = None
        print(e)
    return render(request, 'road_map/index.html', {})

def predict(request):
    metrisdatas = Maps_road.objects.all()
    try:
        if request.GET['date'] == '':
            metrisdatas = metrisdatas.filter(date='20191230')
        else:
            metrisdatas = metrisdatas.filter(date=request.GET['date'])
    except:
        metrisdatas = metrisdatas.filter(date='20191230')
    return render(request,'road_map/ice.html',{'Maps':metrisdatas})

def ice(request):
    return render(request, 'road_map/ice.html', {})

def pathfinding(request):
    now = datetime.datetime.now()
    formattedDate = now.strftime("%Y%m%d")
    data = Maps_road.objects.all()
    try:
        if request.GET['date'] == '':
            data = data.filter(date='20160101')
        else:
            data = data.filter(date=formattedDate)
    except:
        data = data.filter(date='20160101')
    return render(request, 'road_map/pathfinding.html', {'Maps':data})

def blog(request):
    return render(request, 'road_map/blog.html', {})